package com.trsub.app

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.view.View
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.button.MaterialButton
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.slider.Slider
import com.google.android.material.textfield.TextInputEditText
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import okhttp3.OkHttpClient
import java.io.File
import java.util.Collections
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.math.ceil

class SubCue(val start: Double, val end: Double, val text: String)

class MainActivity : AppCompatActivity() {

    companion object {
        const val CHUNK_SEC = 30          // طول كل جزء يُترجم
        const val PAD_BEFORE = 2.0        // صوت إضافي قبل الجزء (لفهم الجملة)
        const val PAD_AFTER = 4.0         // صوت إضافي بعد الجزء (لإكمال آخر جملة)
        const val LOOKAHEAD_SEC = 240.0   // لا نترجم أبعد من 4 دقائق عن موضع المشاهدة
    }

    private lateinit var st: Settings
    private lateinit var player: ExoPlayer
    private lateinit var homeLayout: View
    private lateinit var playerLayout: View
    private lateinit var playerView: PlayerView
    private lateinit var subtitleView: TextView
    private lateinit var topBar: View
    private lateinit var videoTitle: TextView
    private lateinit var statusLine: TextView
    private lateinit var statusPill: TextView
    private lateinit var loadingBox: View
    private lateinit var loadingText: TextView
    private lateinit var keyStatus: TextView
    private lateinit var backCb: OnBackPressedCallback

    private val ui = Handler(Looper.getMainLooper())
    private val rawLock = Any()
    private val rawCues = ArrayList<SubCue>()
    @Volatile private var cues: List<SubCue> = emptyList()
    private val doneChunks: MutableSet<Int> = Collections.synchronizedSet(HashSet<Int>())
    private val failedChunks: MutableSet<Int> = Collections.synchronizedSet(HashSet<Int>())

    private var job: Job? = null
    private var jobGen = 0
    @Volatile private var jobActive = false
    @Volatile private var posSec = 0.0
    @Volatile private var durationSec = 0.0
    @Volatile private var lockedLang: String? = null

    private var videoUri: Uri? = null
    private var videoName = "video"
    private var pausedForSubs = false
    private var resumeAfter = false
    private val contextLines = ArrayDeque<String>()
    private var llmWarned = false
    private var langWarned = false
    @Volatile private var unlimited = false   // إكمال كل الأجزاء (لتصدير SRT كامل)

    private var mlTranslator: Translator? = null
    private var mlLang: String? = null

    private val http = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .writeTimeout(120, TimeUnit.SECONDS)
        .build()

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) openVideo(uri)
    }

    private val createSrt = registerForActivityResult(
        ActivityResultContracts.CreateDocument("text/plain")
    ) { uri ->
        if (uri != null) writeSrt(uri)
    }

    private val hidePill = Runnable { statusPill.visibility = View.GONE }

    // ------------------------------------------------------------------ دورة حياة الشاشة

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        st = Settings(this)

        homeLayout = findViewById(R.id.homeLayout)
        playerLayout = findViewById(R.id.playerLayout)
        playerView = findViewById(R.id.playerView)
        subtitleView = findViewById(R.id.subtitle)
        topBar = findViewById(R.id.topBar)
        videoTitle = findViewById(R.id.videoTitle)
        statusLine = findViewById(R.id.statusLine)
        statusPill = findViewById(R.id.statusPill)
        loadingBox = findViewById(R.id.loadingBox)
        loadingText = findViewById(R.id.loadingText)
        keyStatus = findViewById(R.id.keyStatus)

        player = ExoPlayer.Builder(this).build()
        playerView.player = player
        player.addListener(object : Player.Listener {
            override fun onPositionDiscontinuity(
                oldPosition: Player.PositionInfo,
                newPosition: Player.PositionInfo,
                reason: Int
            ) {
                if (reason == Player.DISCONTINUITY_REASON_SEEK && videoUri != null) {
                    val sec = newPosition.positionMs / 1000.0
                    val idx = (sec / CHUNK_SEC).toInt()
                    posSec = sec
                    if (!doneChunks.contains(idx)) {
                        failedChunks.remove(idx)
                        startProcessing(sec)
                    }
                }
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_READY && player.duration > 0) {
                    durationSec = player.duration / 1000.0
                }
            }
        })

        backCb = object : OnBackPressedCallback(false) {
            override fun handleOnBackPressed() { showHome() }
        }
        onBackPressedDispatcher.addCallback(this, backCb)

        findViewById<View>(R.id.btnPick).setOnClickListener { picker.launch(arrayOf("video/*")) }
        findViewById<View>(R.id.btnSettingsHome).setOnClickListener { showSettings() }
        findViewById<View>(R.id.btnBack).setOnClickListener { showHome() }
        findViewById<View>(R.id.btnOptions).setOnClickListener { showOptions() }

        applySubtitleStyle()
        updateKeyStatus()
        intent?.data?.let { openVideo(it) }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        intent.data?.let { openVideo(it) }
    }

    override fun onStart() {
        super.onStart()
        ui.post(tick)
    }

    override fun onStop() {
        super.onStop()
        ui.removeCallbacks(tick)
        resumeAfter = false
        player.playWhenReady = false
    }

    override fun onDestroy() {
        ui.removeCallbacks(tick)
        job?.cancel()
        mlTranslator?.close()
        player.release()
        super.onDestroy()
    }

    // ------------------------------------------------------------------ الحلقة الدورية (كل 0.1 ثانية)

    private val tick = object : Runnable {
        override fun run() {
            if (videoUri != null) {
                val t = player.currentPosition / 1000.0
                posSec = t
                val idx = (t / CHUNK_SEC).toInt()

                // إيقاف الفيديو مؤقتاً إذا وصلنا لجزء لم تجهز ترجمته بعد
                val wait = st.autoPause && jobActive && idx < totalChunks() &&
                    !doneChunks.contains(idx) && !failedChunks.contains(idx)
                if (wait && !pausedForSubs) {
                    pausedForSubs = true
                    resumeAfter = player.playWhenReady
                    player.playWhenReady = false
                    loadingBox.visibility = View.VISIBLE
                } else if (!wait && pausedForSubs) {
                    pausedForSubs = false
                    loadingBox.visibility = View.GONE
                    if (resumeAfter) player.playWhenReady = true
                }

                // عرض الترجمة المناسبة لهذه اللحظة (مع إزاحة التوقيت التي يضبطها المستخدم)
                val s = t + st.shift
                val c = cues.lastOrNull { s >= it.start && s <= it.end }
                if (c != null) {
                    if (subtitleView.text.toString() != c.text) subtitleView.text = c.text
                    subtitleView.visibility = View.VISIBLE
                } else {
                    subtitleView.visibility = View.GONE
                }

                // شريط الأدوات يظهر مع أزرار التحكم، والترجمة تنزل لأسفل عند اختفائها
                val ctrl = playerView.isControllerFullyVisible
                topBar.visibility = if (ctrl) View.VISIBLE else View.GONE
                val lp = subtitleView.layoutParams as FrameLayout.LayoutParams
                val mb = dp(if (ctrl) 84 else 32)
                if (lp.bottomMargin != mb) {
                    lp.bottomMargin = mb
                    subtitleView.layoutParams = lp
                }
            }
            ui.postDelayed(this, 100)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // ------------------------------------------------------------------ التنقل بين الشاشات

    private fun openVideo(uri: Uri) {
        job?.cancel()
        jobActive = false
        resetSubs()
        videoUri = uri
        videoName = displayName(uri)
        durationSec = readDuration(uri)
        videoTitle.text = videoName
        statusLine.text = ""
        homeLayout.visibility = View.GONE
        playerLayout.visibility = View.VISIBLE
        backCb.isEnabled = true

        player.setMediaItem(MediaItem.fromUri(uri))
        player.prepare()

        if (st.key.isBlank()) {
            player.playWhenReady = true
            setAlert("لتفعيل الترجمة أضف مفتاح API من الإعدادات")
            showSettings()
            return
        }
        if (st.autoPause) {
            pausedForSubs = true
            resumeAfter = true
            player.playWhenReady = false
            loadingBox.visibility = View.VISIBLE
        } else {
            player.playWhenReady = true
        }
        startProcessing(0.0)
    }

    private fun showHome() {
        job?.cancel()
        jobActive = false
        player.stop()
        player.clearMediaItems()
        videoUri = null
        resetSubs()
        subtitleView.visibility = View.GONE
        playerLayout.visibility = View.GONE
        homeLayout.visibility = View.VISIBLE
        backCb.isEnabled = false
        updateKeyStatus()
    }

    private fun resetSubs() {
        synchronized(rawLock) {
            rawCues.clear()
            cues = emptyList()
        }
        doneChunks.clear()
        failedChunks.clear()
        lockedLang = null
        llmWarned = false
        langWarned = false
        unlimited = false
        pausedForSubs = false
        resumeAfter = false
        loadingBox.visibility = View.GONE
    }

    private fun redo() {
        job?.cancel()
        resetSubs()
        // Rebuild every subtitle when the target/source language changes.
        if (videoUri != null) {
            player.seekTo(0)
            posSec = 0.0
        }
        if (st.key.isBlank()) return
        if (st.autoPause) {
            pausedForSubs = true
            resumeAfter = player.playWhenReady
            player.playWhenReady = false
            loadingBox.visibility = View.VISIBLE
        }
        startProcessing(posSec)
    }

    private fun displayName(uri: Uri): String {
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val n = c.getString(0)
                    if (!n.isNullOrBlank()) return n
                }
            }
        } catch (_: Exception) {
        }
        return uri.lastPathSegment ?: "فيديو"
    }

    private fun readDuration(uri: Uri): Double {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(this, uri)
            val ms = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLong() ?: 0L
            if (ms > 0) ms / 1000.0 else 7200.0
        } catch (e: Exception) {
            7200.0
        } finally {
            try { r.release() } catch (_: Exception) {}
        }
    }

    private fun totalChunks(): Int = ceil(durationSec / CHUNK_SEC).toInt().coerceAtLeast(1)

    // ------------------------------------------------------------------ رسائل الحالة

    private fun setStatus(s: String) {
        runOnUiThread {
            statusLine.text = s
            loadingText.text = s
        }
    }

    private fun setAlert(s: String) {
        runOnUiThread {
            statusPill.text = s
            statusPill.visibility = View.VISIBLE
            ui.removeCallbacks(hidePill)
            ui.postDelayed(hidePill, 7000)
        }
    }

    private fun updateKeyStatus() {
        if (st.key.isBlank()) {
            keyStatus.text = "⚠ لم تُضبط الإعدادات بعد — أضف مفتاح API"
            keyStatus.setTextColor(Color.parseColor("#FFB74D"))
        } else {
            keyStatus.text = "✓ الإعدادات جاهزة"
            keyStatus.setTextColor(Color.parseColor("#69F0AE"))
        }
    }

    // ------------------------------------------------------------------ معالجة الصوت والترجمة

    private fun startProcessing(fromSec: Double) {
        val uri = videoUri ?: return
        if (st.key.isBlank()) return
        val prev = job
        prev?.cancel()
        val gen = ++jobGen
        jobActive = true
        job = lifecycleScope.launch(Dispatchers.IO) {
            try {
                prev?.join()
                contextLines.clear()
                val total = totalChunks()
                val start = (fromSec / CHUNK_SEC).toInt().coerceIn(0, total - 1)
                // عند طلب الإكمال الشامل نعالج أيضاً الأجزاء التي سبقت موضع البدء
                val order: List<Int> = if (unlimited)
                    (start until total).toList() + (0 until start).toList()
                else (start until total).toList()
                for (i in order) {
                    ensureActive()
                    // لا نسبق المشاهدة بأكثر من 4 دقائق (لتوفير الحد المجاني)
                    while (!unlimited && i * CHUNK_SEC > posSec + LOOKAHEAD_SEC) {
                        setStatus("✓ الترجمة جاهزة مسبقاً — بانتظار تقدّم الفيديو")
                        delay(1000)
                        ensureActive()
                    }
                    if (doneChunks.contains(i)) continue

                    setStatus("جاري ترجمة الجزء ${i + 1} من $total ...")
                    var ok = false
                    var tries = 0
                    while (!ok && tries < 3) {
                        tries++
                        try {
                            processChunk(uri, i)
                            ok = true
                        } catch (e: CancellationException) {
                            throw e
                        } catch (e: FatalApiError) {
                            setStatus("⚠ ${e.message}")
                            setAlert(e.message ?: "خطأ في المفتاح")
                            runOnUiThread { showSettings() }
                            return@launch
                        } catch (e: Exception) {
                            setStatus("تعذّر الجزء ${i + 1}: ${e.message}")
                            if (tries < 3) delay(2500)
                        }
                    }
                    currentCoroutineContext().ensureActive()
                    if (ok) {
                        doneChunks.add(i)
                        failedChunks.remove(i)
                    } else {
                        failedChunks.add(i)
                        setAlert("تعذّرت ترجمة جزء من الفيديو (تحقق من الإنترنت)")
                    }
                }
                setStatus("✓ اكتملت الترجمة")
            } finally {
                if (gen == jobGen) jobActive = false
            }
        }
    }

    private suspend fun processChunk(uri: Uri, idx: Int) {
        val nomStart = idx.toDouble() * CHUNK_SEC
        val nomEnd = nomStart + CHUNK_SEC
        val startUs = (maxOf(0.0, nomStart - PAD_BEFORE) * 1_000_000).toLong()
        val endUs = ((nomEnd + PAD_AFTER) * 1_000_000).toLong()

        val audio = AudioChunker.extract(this, uri, startUs, endUs, cacheDir, "chunk_$idx") ?: return
        try {
            val lang = if (st.lang != "auto") st.lang else lockedLang
            val result = Transcriber.transcribe(
                http, audio.file, audio.mime, st.url, st.whisperModel, st.key, lang
            )
            val detected = Langs.find(result.language)
            if (st.lang == "auto" && lockedLang == null && detected != null && result.segments.size >= 2) {
                lockedLang = detected.code // نثبّت اللغة حتى لا تتغير عند مقاطع الموسيقى
            }
            val ln = result.language.lowercase().trim()
            val sourceCode = detected?.code ?: if (ln == "arabic") "ar" else if (ln == "english") "en" else ""
            val alreadyTarget = sourceCode.isNotEmpty() && sourceCode == st.targetLang

            // نأخذ فقط الجمل التي تبدأ داخل هذا الجزء، ونتجاهل المكرر من الجزء المجاور
            val picked = ArrayList<SubCue>()
            for (s in result.segments) {
                val a = audio.baseSec + s.start
                val b = audio.baseSec + s.end
                if (a < nomStart - 0.5 || a >= nomEnd + 0.5) continue
                if (overlapsExisting(a, b)) continue
                picked.add(SubCue(a, b, s.text))
            }
            if (picked.isEmpty()) return

            val texts = picked.map { it.text }
            val translated = if (alreadyTarget) texts else translateLines(result.language, detected, texts)

            currentCoroutineContext().ensureActive()
            val fresh = ArrayList<SubCue>()
            for (i in picked.indices) {
                // Keep the source line if a provider returns an empty translation.
                val t = translated.getOrNull(i)?.trim().orEmpty().ifBlank { picked[i].text }
                if (t.isNotEmpty()) fresh.add(SubCue(picked[i].start, picked[i].end, t))
            }
            addCues(fresh)
        } finally {
            audio.file.delete()
        }
    }

    private suspend fun translateLines(langName: String, lang: Lang?, lines: List<String>): List<String> {
        if (st.smart) {
            try {
                val out = LlmTranslator.translate(
                    http, st.url, st.llmModel, st.key,
                    langName.ifBlank { "unknown" }, st.targetLang, lines, contextLines.toList()
                )
                val fixed = ArrayList<String>(lines.size)
                val target = if (st.targetLang == "en") TranslateLanguage.ENGLISH else TranslateLanguage.ARABIC
                for (i in lines.indices) {
                    val translated = out.getOrNull(i)?.trim().orEmpty()
                    if (translated.isNotEmpty()) {
                        fixed.add(translated)
                    } else {
                        // Recover an omitted line with the on-device translator when possible.
                        val src = lang?.ml
                        val recovered = if (src != null && src != target) {
                            try { mlTranslate(src, target, lines[i]) } catch (e: CancellationException) { throw e } catch (_: Exception) { lines[i] }
                        } else lines[i]
                        fixed.add(recovered)
                    }
                }
                rememberDialogueContext(lines, fixed)
                return fixed
            } catch (e: CancellationException) {
                throw e
            } catch (e: FatalApiError) {
                throw e
            } catch (e: Exception) {
                if (!llmWarned) {
                    llmWarned = true
                    setAlert("الترجمة الذكية غير متاحة الآن، استُخدمت الترجمة الاحتياطية")
                }
            }
        }
        val src = lang?.ml ?: detectLang(lines.joinToString(" "))?.ml
        if (src == null) {
            if (!langWarned) {
                langWarned = true
                setAlert("تعذّر تحديد لغة الفيديو — اختر اللغة يدويا من «خيارات»")
            }
            return lines
        }
        val target = if (st.targetLang == "en") TranslateLanguage.ENGLISH else TranslateLanguage.ARABIC
        if (src == target) {
            rememberDialogueContext(lines, lines)
            return lines
        }
        val fallback = lines.map { l ->
            try {
                mlTranslate(src, target, l)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                l
            }
        }
        rememberDialogueContext(lines, fallback)
        return fallback
    }

    /** احفظ الأصل والترجمة معاً كي يفهم المحرك إحالات الضمائر في الجزء التالي. */
    private fun rememberDialogueContext(source: List<String>, translated: List<String>) {
        for (i in source.indices) {
            val src = source[i].replace("\n", " ").trim()
            val dst = translated.getOrNull(i).orEmpty().replace("\n", " ").trim()
            if (src.isNotEmpty()) {
                contextLines.addLast("ORIGINAL: $src -> TRANSLATION: $dst")
            }
        }
        while (contextLines.size > 8) contextLines.removeFirst()
    }

    /** تحديد لغة النص على الجهاز (بديل عندما لا تُعرف لغة المصدر). */
    private suspend fun detectLang(text: String): Lang? {
        val client = LanguageIdentification.getClient()
        return try {
            val tag = client.identifyLanguage(text).await()
            if (tag == "und") null else Langs.find(tag.substringBefore('-'))
        } catch (e: CancellationException) {
            throw e
        } catch (_: Exception) {
            null
        } finally {
            client.close()
        }
    }

    private suspend fun mlTranslate(src: String, target: String, text: String): String {
        val pair = "$src->$target"
        if (mlLang != pair) {
            mlTranslator?.close()
            val t = Translation.getClient(
                TranslatorOptions.Builder()
                    .setSourceLanguage(src)
                    .setTargetLanguage(target)
                    .build()
            )
            setStatus("جاري تحميل نموذج الترجمة الاحتياطي (مرة واحدة)...")
            t.downloadModelIfNeeded(DownloadConditions.Builder().build()).await()
            mlTranslator = t
            mlLang = pair
        }
        return mlTranslator!!.translate(text).await()
    }

    // ------------------------------------------------------------------ تخزين الترجمات وضبط توقيتها

    private fun overlapsExisting(s: Double, e: Double): Boolean = synchronized(rawLock) {
        rawCues.any {
            val ov = minOf(e, it.end) - maxOf(s, it.start)
            ov > 0 && ov >= 0.4 * minOf(e - s, it.end - it.start)
        }
    }

    private fun addCues(newOnes: List<SubCue>) {
        synchronized(rawLock) {
            rawCues.addAll(newOnes)
            rawCues.sortBy { it.start }
            cues = finalizeCues(rawCues)
        }
    }

    /** يضمن مدة عرض كافية للقراءة دون التداخل مع الجملة التالية. */
    private fun finalizeCues(list: List<SubCue>): List<SubCue> {
        val out = ArrayList<SubCue>(list.size)
        for (i in list.indices) {
            val c = list[i]
            val minDur = (0.9 + 0.045 * c.text.length).coerceIn(1.5, 6.0)
            var end = maxOf(c.end, c.start + minDur)
            if (i + 1 < list.size) end = minOf(end, list[i + 1].start - 0.02)
            if (end < c.start + 0.3) end = c.start + 0.3
            out.add(SubCue(c.start, end, c.text))
        }
        return out
    }

    // ------------------------------------------------------------------ مظهر الترجمة

    private fun applySubtitleStyle() {
        subtitleView.textSize = st.fontSize
        if (st.bg) {
            subtitleView.setBackgroundResource(R.drawable.bg_sub)
            subtitleView.setShadowLayer(0f, 0f, 0f, Color.TRANSPARENT)
        } else {
            subtitleView.setBackgroundColor(Color.TRANSPARENT)
            subtitleView.setShadowLayer(8f, 0f, 2f, Color.BLACK)
        }
        subtitleView.typeface = when (st.fontStyle) {
            "bold" -> Typeface.create("sans-serif", Typeface.BOLD)
            "serif" -> Typeface.create("serif", Typeface.NORMAL)
            "mono" -> Typeface.create("monospace", Typeface.NORMAL)
            else -> Typeface.create("sans-serif", Typeface.NORMAL)
        }
    }

    // ------------------------------------------------------------------ قائمة الخيارات

    private fun showOptions() {
        val d = BottomSheetDialog(this)
        val v = layoutInflater.inflate(R.layout.sheet_options, null)
        d.setContentView(v)

        val slider = v.findViewById<Slider>(R.id.sliderFont)
        val fontVal = v.findViewById<TextView>(R.id.fontValue)
        slider.value = st.fontSize.coerceIn(14f, 36f).toInt().toFloat()
        fontVal.text = st.fontSize.toInt().toString()
        slider.addOnChangeListener { _, value, _ ->
            st.fontSize = value
            fontVal.text = value.toInt().toString()
            applySubtitleStyle()
        }

        val swBg = v.findViewById<MaterialSwitch>(R.id.switchBg)
        swBg.isChecked = st.bg
        swBg.setOnCheckedChangeListener { _, checked ->
            st.bg = checked
            applySubtitleStyle()
        }

        val fontStyleBtn = v.findViewById<MaterialButton>(R.id.btnFontStyle)
        val styleNames = arrayOf("واضح", "عريض", "كلاسيكي", "ثابت العرض")
        val styleCodes = arrayOf("normal", "bold", "serif", "mono")
        fun refreshFontStyle() {
            fontStyleBtn.text = styleNames[styleCodes.indexOf(st.fontStyle).coerceAtLeast(0)]
        }
        refreshFontStyle()
        fontStyleBtn.setOnClickListener {
            MaterialAlertDialogBuilder(this)
                .setTitle("نوع خط الترجمة")
                .setSingleChoiceItems(styleNames, styleCodes.indexOf(st.fontStyle).coerceAtLeast(0)) { dlg, which ->
                    st.fontStyle = styleCodes[which]
                    refreshFontStyle()
                    applySubtitleStyle()
                    dlg.dismiss()
                }
                .setNegativeButton("إلغاء", null)
                .show()
        }

        val shiftVal = v.findViewById<TextView>(R.id.shiftValue)
        fun refreshShift() {
            shiftVal.text = if (st.shift == 0f) "بدون تعديل"
            else String.format(Locale.US, "%+.1f ث", st.shift)
        }
        refreshShift()
        v.findViewById<MaterialButton>(R.id.btnEarlier).setOnClickListener {
            st.shift = (st.shift + 0.5f).coerceIn(-10f, 10f)
            refreshShift()
        }
        v.findViewById<MaterialButton>(R.id.btnLater).setOnClickListener {
            st.shift = (st.shift - 0.5f).coerceIn(-10f, 10f)
            refreshShift()
        }

        val swPause = v.findViewById<MaterialSwitch>(R.id.switchAutoPause)
        swPause.isChecked = st.autoPause
        swPause.setOnCheckedChangeListener { _, checked -> st.autoPause = checked }

        val swSmart = v.findViewById<MaterialSwitch>(R.id.switchSmart)
        swSmart.isChecked = st.smart
        swSmart.setOnCheckedChangeListener { _, checked ->
            st.smart = checked
            Toast.makeText(this, "يسري على الأجزاء القادمة — اضغط «إعادة الترجمة» للتطبيق على الكل", Toast.LENGTH_LONG).show()
        }

        val names = (listOf("تلقائي") + Langs.all.map { it.ar }).toTypedArray()
        val codes = listOf("auto") + Langs.all.map { it.code }
        val btnLang = v.findViewById<MaterialButton>(R.id.btnLang)
        btnLang.text = names[codes.indexOf(st.lang).coerceAtLeast(0)]
        btnLang.setOnClickListener {
            val checked = codes.indexOf(st.lang).coerceAtLeast(0)
            MaterialAlertDialogBuilder(this)
                .setTitle("لغة الفيديو")
                .setSingleChoiceItems(names, checked) { dlg, which ->
                    st.lang = codes[which]
                    btnLang.text = names[which]
                    dlg.dismiss()
                    if (videoUri != null) {
                        d.dismiss()
                        redo()
                    }
                }
                .setNegativeButton("إلغاء", null)
                .show()
        }

        val targetBtn = v.findViewById<MaterialButton>(R.id.btnTargetLang)
        fun targetLabel() { targetBtn.text = if (st.targetLang == "en") "🇬🇧 English" else "🇸🇦 العربية" }
        targetLabel()
        targetBtn.setOnClickListener {
            val labels = arrayOf("🇸🇦 العربية", "🇬🇧 English")
            MaterialAlertDialogBuilder(this)
                .setTitle("اختر لغة الترجمة")
                .setSingleChoiceItems(labels, if (st.targetLang == "en") 1 else 0) { dlg, which ->
                    val next = if (which == 1) "en" else "ar"
                    val changed = next != st.targetLang
                    st.targetLang = next
                    targetLabel()
                    dlg.dismiss()
                    if (changed && videoUri != null) {
                        d.dismiss()
                        redo()
                    }
                }
                .setNegativeButton("إلغاء", null)
                .show()
        }

        v.findViewById<MaterialButton>(R.id.btnSrt).setOnClickListener {
            if (cues.isEmpty()) {
                Toast.makeText(this, "لا توجد ترجمة جاهزة بعد", Toast.LENGTH_SHORT).show()
            } else {
                val total = totalChunks()
                val missing = (0 until total).count { !doneChunks.contains(it) }
                d.dismiss()
                if (missing > 0) {
                    MaterialAlertDialogBuilder(this)
                        .setTitle("الترجمة غير مكتملة")
                        .setMessage("يوجد $missing جزء من $total بلا ترجمة بعد. هل تريد إكمالها أولاً (تستهلك من حد الخدمة) أم الحفظ كما هي؟")
                        .setPositiveButton("إكمالها أولاً") { _, _ ->
                            unlimited = true
                            startProcessing(posSec)
                            Toast.makeText(this, "جاري إكمال الترجمة — أعد الحفظ بعد انتهائها", Toast.LENGTH_LONG).show()
                        }
                        .setNegativeButton("حفظ كما هي") { _, _ -> launchSrt() }
                        .setNeutralButton("إلغاء", null)
                        .show()
                } else {
                    launchSrt()
                }
            }
        }
        v.findViewById<MaterialButton>(R.id.btnRedo).setOnClickListener {
            d.dismiss()
            redo()
        }
        v.findViewById<MaterialButton>(R.id.btnApi).setOnClickListener {
            d.dismiss()
            showSettings()
        }

        d.behavior.state = BottomSheetBehavior.STATE_EXPANDED
        d.behavior.skipCollapsed = true
        d.show()
    }

    // ------------------------------------------------------------------ قائمة الإعدادات (المفتاح)

    private fun showSettings() {
        val d = BottomSheetDialog(this)
        val v = layoutInflater.inflate(R.layout.sheet_settings, null)
        d.setContentView(v)

        val etKey = v.findViewById<TextInputEditText>(R.id.etKey)
        val etUrl = v.findViewById<TextInputEditText>(R.id.etUrl)
        val etWhisper = v.findViewById<TextInputEditText>(R.id.etWhisper)
        val etLlm = v.findViewById<TextInputEditText>(R.id.etLlm)
        etKey.setText(st.key)
        etUrl.setText(st.url)
        etWhisper.setText(st.whisperModel)
        etLlm.setText(st.llmModel)

        v.findViewById<MaterialButton>(R.id.btnGetKey).setOnClickListener {
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://console.groq.com/keys")))
            } catch (e: Exception) {
                Toast.makeText(this, "افتح console.groq.com/keys في المتصفح", Toast.LENGTH_LONG).show()
            }
        }
        v.findViewById<MaterialButton>(R.id.btnSave).setOnClickListener {
            st.key = etKey.text.toString().trim()
            st.url = etUrl.text.toString().trim().ifEmpty { Settings.DEFAULT_URL }
            st.whisperModel = etWhisper.text.toString().trim().ifEmpty { Settings.DEFAULT_WHISPER }
            st.llmModel = etLlm.text.toString().trim().ifEmpty { Settings.DEFAULT_LLM }
            d.dismiss()
            updateKeyStatus()
            if (videoUri != null && st.key.isNotBlank()) redo()
        }

        d.behavior.state = BottomSheetBehavior.STATE_EXPANDED
        d.behavior.skipCollapsed = true
        d.show()
    }

    // ------------------------------------------------------------------ حفظ SRT

    private fun launchSrt() {
        createSrt.launch(videoName.substringBeforeLast('.') + (if (st.targetLang == "en") ".en.srt" else ".ar.srt"))
    }

    private fun writeSrt(uri: Uri) {
        val list = cues
        val sb = StringBuilder()
        list.forEachIndexed { i, c ->
            sb.append(i + 1).append('\n')
                .append(srtTime(c.start)).append(" --> ").append(srtTime(c.end)).append('\n')
                .append(c.text).append("\n\n")
        }
        try {
            contentResolver.openOutputStream(uri)?.use { it.write(sb.toString().toByteArray(Charsets.UTF_8)) }
            Toast.makeText(this, "تم حفظ ملف الترجمة ✓", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "تعذّر حفظ الملف", Toast.LENGTH_SHORT).show()
        }
    }

    private fun srtTime(sec: Double): String {
        val ms = (sec * 1000).toLong().coerceAtLeast(0)
        return String.format(
            Locale.US, "%02d:%02d:%02d,%03d",
            ms / 3_600_000, (ms / 60_000) % 60, (ms / 1000) % 60, ms % 1000
        )
    }
}
