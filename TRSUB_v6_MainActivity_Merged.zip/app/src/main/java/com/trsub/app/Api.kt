package com.trsub.app

import kotlinx.coroutines.suspendCancellableCoroutine
import okhttp3.Call
import okhttp3.Callback
import okhttp3.Response
import java.io.IOException
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

object Api {
    /** مدة الانتظار قبل إعادة المحاولة بعد خطأ 429 (تجاوز الحد). */
    fun retryDelayMs(resp: Response, attempt: Int): Long {
        val ra = resp.header("Retry-After")?.toDoubleOrNull()
        return if (ra != null) (ra * 1000).toLong().coerceIn(1000L, 30000L) else 5000L * attempt
    }
}

/** تنفيذ طلب OkHttp بشكل قابل للإلغاء فوراً (عند تقديم الفيديو أو الخروج). */
suspend fun Call.awaitResponse(): Response = suspendCancellableCoroutine { cont ->
    cont.invokeOnCancellation { try { cancel() } catch (_: Throwable) {} }
    enqueue(object : Callback {
        override fun onFailure(call: Call, e: IOException) {
            if (cont.isActive) cont.resumeWithException(e)
        }

        override fun onResponse(call: Call, response: Response) {
            if (cont.isActive) cont.resume(response) else response.close()
        }
    })
}
