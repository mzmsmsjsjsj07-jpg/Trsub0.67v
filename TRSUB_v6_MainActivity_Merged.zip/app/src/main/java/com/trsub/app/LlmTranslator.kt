package com.trsub.app

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/** ترجمة字幕 مع سياق ثنائي اللغة ومراجعة ثانية للترجمة اليابانية إلى العربية. */
object LlmTranslator {

    private val SYSTEM = """
You are a professional subtitle translator for anime, films and series.
Translate every line from the stated source language into the stated target language. Produce fluent, natural subtitles, not a literal word-for-word translation.

CRITICAL RULES FOR JAPANESE DIALOGUE:
- Japanese frequently omits the subject, object and pronouns. Never automatically assume that an omitted subject means "I", "you" or "he". Infer it from the current dialogue and the bilingual context only when the evidence supports that inference.
- Distinguish the speaker (who says the line), the addressee (who is spoken to), and any third person being discussed. Do not switch between them.
- Japanese "彼" and "彼女" can mean he/him and she/her, but do not invent a person's gender or identity where Japanese leaves it unspecified.
- Arabic often forces choices about gender. When the source and context do not establish gender or the referent, prefer a natural Arabic sentence that avoids an unnecessary explicit pronoun or gender guess. Do not make the Arabic awkward just to avoid a pronoun.
- Keep references to characters, names, relationships, number, negation, tense, questions and emotional intent consistent across lines. Do not reverse who does what to whom.
- Treat previous bilingual context as evidence for continuity, not as text to translate again. Each context item is formatted as SOURCE and TARGET.

GENERAL RULES:
- Translate idioms by meaning; preserve sarcasm, jokes, emotion and conversational tone.
- Use Modern Standard Arabic that sounds natural in spoken dialogue. Keep it concise but do not drop important meaning.
- Do not invent explanations or details. Do not omit spoken content. Do not leave a spoken line empty.
- Keep exactly one output string per input line in the same order. Return JSON only: {"translations": ["..."]}. No markdown or commentary.
""".trimIndent()

    private val REVIEW_SYSTEM = """
You are a strict senior subtitle editor specializing in Japanese-to-Arabic dialogue.
You receive the original lines, a first Arabic translation draft, and recent bilingual dialogue context. Review and improve the draft rather than translating blindly.

For every line, check especially:
1. Is the implied Japanese subject/object inferred correctly from context?
2. Is the speaker confused with the addressee or a third person? Are أنا/أنت/هو/هي and verb gender/number consistent?
3. Has the draft guessed the gender or identity of a person not established by the source/context? If uncertain, use a fluent Arabic wording that avoids an unsupported pronoun where possible.
4. Is the Arabic natural and clear, with the correct idiom, negation, tone and meaning?
5. Has any information been invented, dropped, or moved to a different line?

Do not force a pronoun merely because Arabic permits one. Do not change a correct line unnecessarily. Use the context as evidence but do not infer more than it supports. Preserve one-to-one line alignment and return exactly one Arabic string for each original line.
Return valid JSON only in the form {"translations": ["..."]}; no commentary or markdown.
""".trimIndent()

    suspend fun translate(
        http: OkHttpClient, baseUrl: String, model: String, key: String,
        sourceLang: String, targetLang: String, lines: List<String>, context: List<String>
    ): List<String> {
        val user = JSONObject()
            .put("source_language", sourceLang)
            .put("target_language", if (targetLang == "en") "English" else "Arabic (Modern Standard Arabic; natural dialogue subtitles)")
            .put("previous_dialogue_context_source_and_target", JSONArray(context))
            .put("lines_to_translate", JSONArray(lines))

        val first = requestTranslations(
            http, baseUrl, model, key, SYSTEM, user, lines.size, attempts = 4, temperature = 0.15
        )

        // The extra quality pass is limited to Japanese -> Arabic: it checks pronouns,
        // implied subjects and naturalness. If it fails, keep the successful first pass.
        if (!isJapanese(sourceLang) || targetLang != "ar" || lines.isEmpty()) return first
        return try {
            val reviewUser = JSONObject()
                .put("source_language", sourceLang)
                .put("target_language", "Arabic (Modern Standard Arabic; natural dialogue subtitles)")
                .put("previous_dialogue_context_source_and_target", JSONArray(context))
                .put("original_lines", JSONArray(lines))
                .put("draft_translations", JSONArray(first))
            val reviewed = requestTranslations(
                http, baseUrl, model, key, REVIEW_SYSTEM, reviewUser,
                lines.size, attempts = 1, temperature = 0.05
            )
            reviewed.mapIndexed { index, line -> line.ifBlank { first[index] } }
        } catch (e: CancellationException) {
            throw e
        } catch (_: Exception) {
            // Do not lose the first translation if the optional review is unavailable
            // (for example, rate limit or transient network failure).
            first
        }
    }

    private fun isJapanese(sourceLang: String): Boolean {
        val s = sourceLang.lowercase(Locale.ROOT).trim()
        return s == "ja" || s.startsWith("ja-") || s == "japanese" || s == "اليابانية"
    }

    private suspend fun requestTranslations(
        http: OkHttpClient, baseUrl: String, model: String, key: String,
        system: String, user: JSONObject, expected: Int, attempts: Int, temperature: Double
    ): List<String> {
        val bodyStr = JSONObject()
            .put("model", model)
            .put("temperature", temperature)
            .put("response_format", JSONObject().put("type", "json_object"))
            .put(
                "messages", JSONArray()
                    .put(JSONObject().put("role", "system").put("content", system))
                    .put(JSONObject().put("role", "user").put("content", user.toString()))
            ).toString()

        for (attempt in 1..attempts) {
            val req = Request.Builder()
                .url(baseUrl.trimEnd('/') + "/chat/completions")
                .header("Authorization", "Bearer $key")
                .post(bodyStr.toRequestBody("application/json".toMediaType()))
                .build()

            val resp = http.newCall(req).awaitResponse()
            val code = resp.code
            val wait = Api.retryDelayMs(resp, attempt)
            val text = resp.body?.string() ?: ""
            resp.close()

            when {
                code in 200..299 -> return parse(text, expected)
                code == 401 || code == 403 -> throw FatalApiError("مفتاح API غير صحيح أو لا يملك صلاحية")
                code == 429 || code in 500..599 -> {
                    if (attempt < attempts) delay(wait)
                    else throw Exception("الخدمة مشغولة حالياً، أعد المحاولة بعد قليل")
                }
                else -> throw Exception("خطأ ($code): ${text.take(120)}")
            }
        }
        throw Exception("تعذّر الاتصال")
    }

    private fun parse(json: String, expected: Int): List<String> {
        val raw = JSONObject(json)
            .getJSONArray("choices").getJSONObject(0)
            .getJSONObject("message").optString("content", "").trim()
        if (raw.isEmpty()) throw Exception("رد فارغ من النموذج")
        val content = raw.removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        val arr = JSONObject(content).getJSONArray("translations")
        if (arr.length() != expected) throw Exception("عدد الأسطر المترجمة غير مطابق")
        val out = ArrayList<String>(expected)
        for (i in 0 until arr.length()) out.add(arr.optString(i, "").trim())
        return out
    }
}
